package com.e.avision;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.widget.ImageView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.Buffer;

import static com.e.avision.Camera_Activity.LOG_TAG;
import static com.e.avision.Util.md5;

public class InfoToSend {

    public byte[] byteImage;
    public Buffer mBuffer;
    public String user_name;
    public String user_key;
    public String img_name;
    public String img_key;
    public String URL = "http://avision.vinkodrf.ru:22955?metod=";


    private HttpURLConnection con;
    private JSONObject mServerData;

    String twoHyphens = "--";
    String boundary =  "****SOME_USER_SENDS_SOME_INFO_TO_SERVER****";
    String lineEnd = "\r\n";



    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public void setUser_key(String user_key) {
        this.user_key = user_key;
    }

    public void setImg_name(String img_name) {
        this.img_name = img_name;
    }

    public void setImg_key(String img_key) {
        this.img_key = img_key;
    }

    public InfoToSend(String user_name, String user_key, String img_name, String img_key, byte[] byteImage){

        this.byteImage = byteImage;
        this.user_name = user_name;
        this.user_key = user_key;
        this.img_name = img_name;
        this.img_key = img_key;

    }

    public void setByteImage(byte[] byteImage) {
        this.byteImage = byteImage;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void createURL(String method_name) {
        try {
            URL url = new URL(URL + method_name);
            this.con = (HttpURLConnection) url.openConnection();
            if(method_name != "get_img") {
                con.setRequestMethod("POST");
                con.setRequestProperty("Authorization", user_name + ":" + md5(user_name + method_name + user_key + img_name));
                con.setRequestProperty("Accept", "application/json");
                con.setRequestProperty("Content-Type", "multipart/form-data; boundary="+boundary);
                if (method_name == "get_result") {
                    con.setRequestProperty("imginfo", img_name);
                }
                Log.i(LOG_TAG, URL + method_name);
                Log.i(LOG_TAG, "Authorization: "+user_name + ":" + user_name + " "+method_name + " "+user_key + " "+img_name);
                Log.i(LOG_TAG, "Accept: application/json");
                Log.i(LOG_TAG, "Content-Type: multipart/form-data; boundary="+boundary);
                if (method_name == "get_result") {
                    Log.i(LOG_TAG, "imginfo: "+img_name);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public JSONObject new_user() throws JSONException {

        createURL("new_user");
        StringBuffer content = new StringBuffer();

        try {
            int status = con.getResponseCode();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            con.disconnect();

            Log.i(LOG_TAG, "Response status: " + status);

        } catch (IOException e) {
            e.printStackTrace();
            Log.e(LOG_TAG, "HTTP NE YDALOS'");
        }

        Log.i(LOG_TAG, content.toString());

        try {
            mServerData = new JSONObject(content.toString());
            Log.i(LOG_TAG, "User's key: "+ mServerData.getString("key"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return mServerData;

    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public JSONObject new_img() throws JSONException {

        createURL("new_img");
        StringBuffer content = new StringBuffer();

        try {
            DataOutputStream mOutputStream = new DataOutputStream(con.getOutputStream());


            mOutputStream.writeBytes(twoHyphens + boundary + lineEnd);
            mOutputStream.writeBytes("Content-Disposition: form-data; name=\"" + img_name + "\"; filename=\"" + img_name +"\"" + lineEnd);
            mOutputStream.writeBytes("Content-Type: image/jpeg" + lineEnd);
            mOutputStream.writeBytes("Content-Transfer-Encoding: binary" + lineEnd);
            mOutputStream.writeBytes(lineEnd);

            mOutputStream.write(byteImage);

            mOutputStream.writeBytes(lineEnd);
            mOutputStream.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);


            int status = con.getResponseCode();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            con.disconnect();
            mOutputStream.flush();
            mOutputStream.close();

            Log.i(LOG_TAG, "Response status: " + status);

        } catch (IOException e) {
            e.printStackTrace();
            Log.e(LOG_TAG, "HTTP NE YDALOS'");
        }

        try {
            mServerData = new JSONObject(content.toString());
            Log.i(LOG_TAG, "Server answered for new_img - "+mServerData.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return mServerData;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public JSONObject get_result() throws JSONException {

        createURL("get_result");
        StringBuffer content = new StringBuffer();

        try {
            int status = con.getResponseCode();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            con.disconnect();

            Log.i(LOG_TAG, "Response status: " + status);

        } catch (IOException e) {
            e.printStackTrace();
            Log.e(LOG_TAG, "HTTP NE YDALOS'");
        }


        try {
            mServerData = new JSONObject(content.toString());
            Log.i(LOG_TAG, "Server answered for get_result - "+mServerData.toString());
            Log.i(LOG_TAG, "img_key - "+mServerData.getString("img_key"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return mServerData;

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public Bitmap get_img(ImageView imageView){

        byteImage = new byte[0];
        InputStream mInputStream;
        Bitmap mBitmap = null;
        ByteArrayOutputStream mStream = null;
        
        try {
            URL url = new URL(URL + "get_img&img=" + img_name + "&user=" + user_name + "&key=" + img_key);

            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");

            Log.i(LOG_TAG,URL + "get_img&img=" + img_name + "&user=" + user_name + "&key=" + img_key);

            int status = con.getResponseCode();

            mInputStream = con.getInputStream();
            mBitmap = BitmapFactory.decodeStream(mInputStream);

            mInputStream.close();
            con.disconnect();
            Log.i(LOG_TAG,"Response status: " + status);

            /*Log.i(LOG_TAG,"Server answered for get_img: "+content.toString());
            byteImage = content.toString().getBytes();*/
        }
        catch (IOException e){
            e.printStackTrace();
        }
        /*try {
            mInputStream = new URL(URL + "get_img&img=" + img_name + "&user=" + user_name + "&key=" + img_key).openStream();
            mBitmap = BitmapFactory.decodeStream(mInputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }*/

        //mBitmap.copyPixelsToBuffer(mBuffer);

        return mBitmap;
         
    }
}
