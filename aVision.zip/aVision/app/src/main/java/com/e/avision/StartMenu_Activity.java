package com.e.avision;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import static com.e.avision.Camera_Activity.LOG_TAG;

public class StartMenu_Activity extends AppCompatActivity {

    private Button button1;
    public String new_user = "new_user";
    public InfoToSend mInfoToSend;

    private String user_name;
    private String user_key;

    public String defaultKey = new String("G!g9gCe&@g@#w5l");

    public SharedPreferences mSharedPreferences;

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_menu_activity);
        Log.i(LOG_TAG, "Start_Menu_Activity: onCreate");
        //mSharedPreferences = getSharedPreferences("aVisionPreferences", MODE_PRIVATE);

        /*if(!mSharedPreferences.contains("user_name")){
            SharedPreferences.Editor mEditor = mSharedPreferences.edit();
            mEditor.putString("user_name", "test_0000012345");
            mEditor.commit();
        }
        if(!mSharedPreferences.contains("user_key")){
            SharedPreferences.Editor mEditor = mSharedPreferences.edit();
            mEditor.putString("user_key", defaultKey);
            mEditor.commit();
        }


        user_key = mSharedPreferences.getString("user_key","");

        user_name = mSharedPreferences.getString("user_name",null);

        if(user_key.equals(defaultKey)) {
            mInfoToSend = new InfoToSend(user_name, user_key, "no", null, null);
            new ContentToServer(mInfoToSend, mSharedPreferences, null).execute(new_user);
        }*/

        button1 = findViewById(R.id.button4);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StartMenu_Activity.this, Camera_Activity.class);
                startActivity(intent);
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onResume() {
        super.onResume();
        Log.i(LOG_TAG, "Start_Menu_Activity: onResume");
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onPause() {
        super.onPause();
        Log.i(LOG_TAG, "Start_Menu_Activity: onPause");
    }
}
