package com.e.avision;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.widget.ImageView;

public class GetBitmapAsync extends AsyncTask<String, Integer, Bitmap> {

    private InfoToSend mInfoToSend;
    private ImageView mImageView;
    private Bitmap mBitmap;

    public GetBitmapAsync(InfoToSend infoToSend, ImageView imageView){
        this.mInfoToSend = infoToSend;
        this.mImageView = imageView;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected Bitmap doInBackground(String... strings) {

        if(strings[0].equals("get_img")){
            mBitmap = mInfoToSend.get_img(mImageView);
        }
        return mBitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);

        int width = mBitmap.getWidth();
        int height = mBitmap.getHeight();

        width = width*4;
        height = height*4;

        Bitmap mScaledBitmap = Bitmap.createScaledBitmap(mBitmap, height, width, false);

        mImageView.setImageBitmap(mScaledBitmap);
    }
}
