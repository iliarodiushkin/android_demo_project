package com.e.avision;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Util{

    public static byte[] mByteJPEG;

    public static String md5(final String s){

        final String MD5 = "MD5";
        try{
            MessageDigest digest = java.security.MessageDigest.getInstance(MD5);
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();


            String mHashResult = new String();
            for (byte aMessageDigest : messageDigest) {
                String h = Integer.toHexString(0xFF & aMessageDigest);
                while (h.length() < 2)
                    h = "0" + h;
                mHashResult+= h;
            }
            return mHashResult;

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }


    public static String createMd5(String user_name, String method_name, String personalKey, String img_name){

        String result;
        result = md5(user_name+method_name+personalKey+img_name);

        return result;
    }

    public static SharedPreferences getSharedPreferences(AppCompatActivity appCompatActivity){
        return appCompatActivity.getSharedPreferences("aVisionPreferences", Context.MODE_PRIVATE);
    }
}
