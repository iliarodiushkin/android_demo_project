package com.e.avision;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Size;
import android.util.SparseIntArray;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
;
import java.nio.ByteBuffer;
import java.util.Arrays;

@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class Camera_Activity extends AppCompatActivity {

    public static SharedPreferences mSharedPreferences;

    private String user_name;
    private String user_key;
    private String cur_img_name;
    //private int j = 0;


    //public static InfoToSend mInfoToSend = new InfoToSend("test_000002", "TX202mpZ1Fao43deMxNm0a0s85wLqXpu", "testimage_02.jpg", null, null);

    public static final String LOG_TAG = "myLogs";
    private CameraManager mCameraManager = null;
    private ImageReader mImageReader;

    CameraService[] mCameras = null;
    private final int CAMERA1 = 0;
    private final int CAMERA2 = 1;
    private int CAMERA_NUM = 0;


    private static final SparseIntArray ORIENTATIONS = new SparseIntArray();

    static {

        ORIENTATIONS.append(Surface.ROTATION_0, 90);
        ORIENTATIONS.append(Surface.ROTATION_90, 0);
        ORIENTATIONS.append(Surface.ROTATION_180, 270);
        ORIENTATIONS.append(Surface.ROTATION_270, 180);

    }

    private Size mPreviewSize = new Size(470, 840);


    private ImageButton mButtonMakeShot = null;
    private ImageButton mButtonChangeCamera = null;
    private ImageButton mButtonComeBack = null;

    private TextureView mTextureView = null;
    private ImageView imageView6 = null;
    private ImageView imageView8 = null;

    private HandlerThread mBackgroundThread;
    private Handler mBackgroundHandler = null;

    private void startBackgroundThread() {
        mBackgroundThread = new HandlerThread("CameraBackground");
        mBackgroundThread.start();
        mBackgroundHandler = new Handler(mBackgroundThread.getLooper());
    }

    private void stopBackgroundThread() {
        mBackgroundThread.quitSafely();
        try {
            mBackgroundThread.join();
            mBackgroundThread = null;
            mBackgroundHandler = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private final TextureView.SurfaceTextureListener mSurfaceTextureListener = new TextureView.SurfaceTextureListener() {
        @RequiresApi(api = Build.VERSION_CODES.M)
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            mCameras[CAMERA_NUM].openCamera(width, height);
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
            configTransform(width, height);
        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {
        }
    };

    @SuppressLint("WrongViewCast")
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSharedPreferences = getSharedPreferences("aVisionPreferences", MODE_PRIVATE);

        SharedPreferences.Editor mEditor = mSharedPreferences.edit();
        if (!mSharedPreferences.contains("cur_img_name")) {
            mEditor.putString("cur_img_name", "masterMAX_"+((int)(40700+Math.random()*90)));
        }
        if (!mSharedPreferences.contains("j")) {
            mEditor.putInt("j", 0);
        }
        if (mSharedPreferences.contains("cur_img_status")) {
            mEditor.putString("cur_img_status", "work");
        }
        mEditor.commit();

       /* user_name = mSharedPreferences.getString("user_name", "");
        user_key = mSharedPreferences.getString("user_key", "");
        cur_img_name = mSharedPreferences.getString("cur_img_name", "");
        j = mSharedPreferences.getInt("j", 0);

        mInfoToSend.setUser_name(user_name);
        mInfoToSend.setUser_key(user_key);
        mInfoToSend.setImg_name(cur_img_name + j + ".jpg");
*/
        if (checkSelfPermission(Manifest.permission.CAMERA) !=
                PackageManager.PERMISSION_GRANTED
                ||
                (ContextCompat.checkSelfPermission(Camera_Activity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
        ) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }

        mButtonChangeCamera = findViewById(R.id.imageButton8);
        mButtonComeBack = findViewById(R.id.imageButton9);
        mButtonMakeShot = findViewById(R.id.imageButton6);
        mTextureView = findViewById(R.id.textureView);
        imageView8 = findViewById(R.id.imageView8);
        imageView6 = findViewById(R.id.imageView6);


        mButtonChangeCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCameras[CAMERA1].isOpen()) {
                    mCameras[CAMERA1].closeCamera();
                    if (mCameras[CAMERA2] != null) {
                        mCameras[CAMERA2].openCamera(mTextureView.getWidth(), mTextureView.getHeight());
                        CAMERA_NUM = 1;
                    }
                } else {
                    mCameras[CAMERA2].closeCamera();
                    if (mCameras[CAMERA1] != null) {
                        mCameras[CAMERA1].openCamera(mTextureView.getWidth(), mTextureView.getHeight());
                        CAMERA_NUM = 0;
                    }
                }
            }
        });

        mButtonComeBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //здесь нужно дописать возвращение в главное меню, котрого пока что нет
                Intent intent = new Intent(Camera_Activity.this, StartMenu_Activity.class);
                startActivity(intent);
                Camera_Activity.this.finish();
            }
        });

        mButtonMakeShot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //здесь надо дописать сохранение в память и переход в третью менюшку

                int j = mSharedPreferences.getInt("j",0);
                j++;
                SharedPreferences.Editor mEditor = mSharedPreferences.edit();
                mEditor.putInt("j", j);
                mEditor.commit();

               // mInfoToSend.setImg_name(cur_img_name + j + ".jpg");

                /*Intent intent = new Intent(Camera_Activity.this, Server_Activity.class);
                startActivity(intent);
*/
                mCameras[CAMERA_NUM].makePhoto();
            }
        });


        mCameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            //список камер
            mCameras = new CameraService[mCameraManager.getCameraIdList().length];


            for (String cameraID : mCameraManager.getCameraIdList()) {
                //пишем ID камер
                Log.i(LOG_TAG, "Camera_ID - " + cameraID);
                int id = Integer.parseInt(cameraID);

                //получаем характеристики камер
                CameraCharacteristics CamChar = mCameraManager.getCameraCharacteristics(cameraID);

                //выходной формат для камеры
                StreamConfigurationMap configurationMap = CamChar.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);

                //определение направленности камеры (фронтальная или задняя)
                int faceing = CamChar.get(CameraCharacteristics.LENS_FACING);

                if (faceing == CameraCharacteristics.LENS_FACING_FRONT) {
                    Log.i(LOG_TAG, "Camera - " + cameraID + " is front camera");
                }
                if (faceing == CameraCharacteristics.LENS_FACING_BACK) {
                    Log.i(LOG_TAG, "Camera - " + cameraID + " is back camera");
                }

                //разрешение для jpeg-ов (длинна Х ширина)
                Size[] sizesJPEG = configurationMap.getOutputSizes(ImageFormat.JPEG);

                //выводим разрешение
                if (sizesJPEG != null) {
                    for (Size object : sizesJPEG) {
                        Log.i(LOG_TAG, "w " + object.getWidth() + "   h " + object.getHeight());
                    }
                } else {
                    Log.i(LOG_TAG, "Don't support jpeg");
                }

                mCameras[id] = new CameraService(mCameraManager, cameraID);
            }

        } catch (CameraAccessException e) {
            Log.e(LOG_TAG, e.getMessage());
            e.printStackTrace();
        }


    }


    public class CameraService {
        public Activity activity = Camera_Activity.this;
        private String mCameraID;
        private CameraDevice mCameraDevice = null;
        private CameraCaptureSession mCaptureSession;
        private File mFile;


        public CameraService(CameraManager cameraManager, String cameraID) {
            mCameraManager = cameraManager;
            mCameraID = cameraID;
        }

        public void makePhoto() {
            SharedPreferences.Editor mEditor = mSharedPreferences.edit();
            mEditor.putString("new_img_status", " ");
            mEditor.commit();

            Log.i(LOG_TAG, "TIME make photo");

            //mFile = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), cur_img_name + j + ".jpg");
            try {
                final CaptureRequest.Builder captureBuild = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                if (!(Surface.ROTATION_90 == activity.getWindowManager().getDefaultDisplay().getRotation()) || (Surface.ROTATION_270 == activity.getWindowManager().getDefaultDisplay().getRotation())) {
                    captureBuild.set(CaptureRequest.JPEG_ORIENTATION, 90);
                }

                captureBuild.addTarget(mImageReader.getSurface());
                CameraCaptureSession.CaptureCallback CaptureCallback = new CameraCaptureSession.CaptureCallback() {
                    @Override
                    public void onCaptureCompleted(@NonNull CameraCaptureSession session, @NonNull CaptureRequest request, @NonNull TotalCaptureResult result) {
                        super.onCaptureCompleted(session, request, result);
                    }
                };


                Log.i(LOG_TAG, "TIME before stop session");

                mCaptureSession.stopRepeating();
                //mCaptureSession.abortCaptures();
                mCaptureSession.capture(captureBuild.build(), CaptureCallback, mBackgroundHandler);

                Log.i(LOG_TAG, "TIME after stop session");

            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
        }

        private final ImageReader.OnImageAvailableListener mOnImageAvailableListener = new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader reader) {
                Log.i(LOG_TAG, "ready to save");
                Toast.makeText(Camera_Activity.this, "Изображение сохранено и отправлено на обработку", Toast.LENGTH_SHORT).show();
                //mBackgroundHandler.post(new ImageSaver(reader.acquireNextImage(), mFile));

                ByteBuffer buffer = reader.acquireNextImage().getPlanes()[0].getBuffer();
                byte[] bytes = new byte[buffer.remaining()];
                buffer.get(bytes);

                Util.mByteJPEG = bytes;

                Intent intent = new Intent(Camera_Activity.this, Server_Activity.class);
                startActivity(intent);
                Log.i(LOG_TAG, "before finish activity");
                Camera_Activity.this.finish();

            }
        };


        public boolean isOpen() {

            if (mCameraDevice == null) {
                return false;
            } else {
                return true;
            }
        }

        @RequiresApi(api = Build.VERSION_CODES.M)
        public void openCamera(int width, int height) {

            configTransform(width, height);

            try {
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    mCameraManager.openCamera(mCameraID, mCameraCallback, mBackgroundHandler);
                    Log.i(LOG_TAG, "open camera - " + mCameraID);
                }

            } catch (CameraAccessException e) {
                Log.i(LOG_TAG, e.getMessage());
            }
        }

        public void closeCamera() {
            if (mCameraDevice != null) {
                mCameraDevice.close();
                mCameraDevice = null;
            }
        }

        //колбэк из верхней части

        private CameraDevice.StateCallback mCameraCallback = new CameraDevice.StateCallback() {
            @Override
            public void onOpened(CameraDevice camera) {
                mCameraDevice = camera;
                Log.i(LOG_TAG, "Open camera - " + mCameraDevice.getId());
                //вызов превью
                createCameraPreviewSession();


            }

            @Override
            public void onDisconnected(CameraDevice camera) {
                mCameraDevice.close();

                Log.i(LOG_TAG, "Disconnect camera - " + mCameraDevice.getId());
                mCameraDevice = null;

            }

            @Override
            public void onError(CameraDevice camera, int error) {
                Log.i(LOG_TAG, "error/// some problems with camera - " + mCameraDevice.getId() + "  error: " + error);

            }
        };

        private void createCameraPreviewSession() {

            mImageReader = ImageReader.newInstance(1920, 1080, ImageFormat.JPEG, 1);
            mImageReader.setOnImageAvailableListener(mOnImageAvailableListener, mBackgroundHandler);

            SurfaceTexture texture = mTextureView.getSurfaceTexture();

            texture.setDefaultBufferSize(2304/2 + 260, 1306/2);

            Surface surface = new Surface(texture);

            try {
                final CaptureRequest.Builder builder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);

                builder.addTarget(surface);
                mCameraDevice.createCaptureSession(Arrays.asList(surface, mImageReader.getSurface()), new CameraCaptureSession.StateCallback() {

                    @Override
                    public void onConfigured(CameraCaptureSession session) {
                        mCaptureSession = session;
                        try {
                            mCaptureSession.setRepeatingRequest(builder.build(), null, null);
                        } catch (CameraAccessException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onConfigureFailed(CameraCaptureSession session) {
                        Log.e(LOG_TAG, "configuration capture error");
                    }
                }, null);
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(LOG_TAG, "START");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(LOG_TAG, "PAUSE");
        if ((mCameras[CAMERA1] != null) && (mCameras[CAMERA2] != null)) {
            mCameras[CAMERA1].closeCamera();
            mCameras[CAMERA2].closeCamera();

        }

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onResume() {
        super.onResume();
        Log.i(LOG_TAG, "Camera_Activity: onResume");

        if (mTextureView.isAvailable()) {


            if (mCameras[CAMERA_NUM] != null) {
                mCameras[CAMERA_NUM].openCamera(mTextureView.getWidth(), mTextureView.getHeight());
            }
        } else {
            mTextureView.setSurfaceTextureListener(mSurfaceTextureListener);

        }
        //startBackgroundThread();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(LOG_TAG, "Camera_Activity: onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(LOG_TAG, "Camera_Activity: onDestroy");
        //stopBackgroundThread();
    }


    /*private static class ImageSaver implements Runnable {

        private final Image mImage;
        private final File mFile;

        public JSONObject mContentFromServer;

        long mStartTime;
        long mCurrentTime;


        ImageSaver(Image image, File file) {

            mFile = file;
            mImage = image;
            mImage.setCropRect(new Rect(33, 33, 500, 700));
        }

        @Override
        public void run() {
            ByteBuffer buffer = mImage.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);
            FileOutputStream outputStream = null;
            SharedPreferences.Editor mEditor = mSharedPreferences.edit();

            mInfoToSend.setByteImage(bytes);

            try {
                mInfoToSend.new_img();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            mEditor.putString("new_img_status", "ok");
            mEditor.commit();


            try {
                outputStream = new FileOutputStream(mFile);
                outputStream.write(bytes);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                mImage.close();
                if (outputStream != null) {
                    try {
                        outputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }


            try {
                mContentFromServer = new JSONObject(mInfoToSend.get_result());
                mStartTime = System.currentTimeMillis();
                mEditor.putString("cur_img_status", mContentFromServer.getString("img_status"));
                mEditor.commit();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            while (mSharedPreferences.getString("cur_img_status", "work").equals("work")) {
                mCurrentTime = System.currentTimeMillis();
                if ((mCurrentTime - mStartTime) >= 10) {
                    try {
                        mStartTime = System.currentTimeMillis();
                        mContentFromServer = new JSONObject(mInfoToSend.get_result());
                        mEditor.putString("cur_img_status", mContentFromServer.getString("img_status"));
                        mEditor.commit();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
            Log.i(LOG_TAG, "Img was successfully processed");
            try {
                mEditor.putString("cur_img_key", mContentFromServer.getString("img_key"));
                mEditor.commit();
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }*/

    private void configTransform(int viewWidth, int viewHeight) {

        Activity activity = Camera_Activity.this;

        if (activity == null || mTextureView == null || mPreviewSize == null) {
            return;
        }

        int rotation = activity.getWindowManager().getDefaultDisplay().getRotation();

        Matrix matrix = new Matrix();

        if (Surface.ROTATION_90 == rotation || Surface.ROTATION_270 == rotation) {
            mPreviewSize = new Size(840, 420);
        } else {
            mPreviewSize = new Size(460, 840);
        }


        RectF viewRect = new RectF(0, 0, viewWidth, viewHeight);
        RectF bufferRect = new RectF(0, 0, mPreviewSize.getHeight(), mPreviewSize.getWidth());

        float centerX = viewRect.centerX();
        float centerY = viewRect.centerY();


        if (Surface.ROTATION_90 == rotation || Surface.ROTATION_270 == rotation) {
            bufferRect.offset(centerX - bufferRect.centerX(), centerY - bufferRect.centerY());
            matrix.setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL);
            float scale = Math.max(
                    (float) viewHeight / mPreviewSize.getHeight(),
                    (float) viewWidth / mPreviewSize.getWidth());
            matrix.postScale(scale, scale, centerX, centerY);
            matrix.postRotate(90 * (rotation - 2), centerX, centerY);
        } else if (Surface.ROTATION_180 == rotation) {
            matrix.postRotate(180, centerX, centerY);
        } else {


            //bufferRect.offset(centerX - bufferRect.centerX(), centerY - bufferRect.centerY());
            //matrix.setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL);
            float scale = Math.max(
                    (float) viewHeight / mPreviewSize.getHeight(),
                    (float) viewWidth / mPreviewSize.getWidth());

            matrix.postScale(scale, scale, centerX, centerY);

        }
        //mTextureView.setTransform(matrix);
    }

    /*public static class MyNewAsync extends AsyncTask<String, Integer, String> {

        private byte[] mBytes = null;
        private File mFile = null;
        private JSONObject mContentFromServer;
        private Long mStartTime;
        private Long mCurrentTime;

        protected MyNewAsync(byte[] bytes, File file) {

            this.mBytes = bytes;
            this.mFile = file;
        }

        @Override
        protected String doInBackground(String... strings) {

            FileOutputStream outputStream = null;
            SharedPreferences.Editor mEditor = mSharedPreferences.edit();

            mInfoToSend.setByteImage(mBytes);

            try {
                mInfoToSend.new_img();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            mEditor.putString("new_img_status", "ok");
            mEditor.commit();


            try {
                outputStream = new FileOutputStream(mFile);
                outputStream.write(mBytes);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (outputStream != null) {
                    try {
                        outputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }


            try {
                mContentFromServer = new JSONObject(mInfoToSend.get_result());
                mStartTime = System.currentTimeMillis();
                mEditor.putString("cur_img_status", mContentFromServer.getString("img_status"));
                mEditor.commit();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            while (mSharedPreferences.getString("cur_img_status", "work").equals("work")) {
                mCurrentTime = System.currentTimeMillis();
                if ((mCurrentTime - mStartTime) >= 10) {
                    try {
                        mStartTime = System.currentTimeMillis();
                        mContentFromServer = new JSONObject(mInfoToSend.get_result());
                        mEditor.putString("cur_img_status", mContentFromServer.getString("img_status"));
                        mEditor.commit();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
            Log.i(LOG_TAG, "Img was successfully processed");
            try {
                mEditor.putString("cur_img_key", mContentFromServer.getString("img_key"));
                mEditor.commit();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
        }
    }*/

}
