package com.e.avision;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.ContactsContract;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.widget.ImageView;

import org.json.JSONException;
import org.json.JSONObject;


import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;

import static com.e.avision.Camera_Activity.LOG_TAG;


public class ContentToServer extends AsyncTask<String, Integer, byte[]> {

    public JSONObject mServerData;
    public byte[] mByteImage;
    public byte[] mByteContent;
    public ByteArrayOutputStream mOutStream;

    public InfoToSend mInfoToSend;
    public SharedPreferences mSharedPreferences;
    private ImageView mImageView;
    private Bitmap mBitmap;


    public ContentToServer(InfoToSend infoToSend, SharedPreferences mSharedPreferences, ImageView imageView) {

        this.mByteImage = infoToSend.byteImage;
        this.mInfoToSend = infoToSend;
        this.mSharedPreferences = mSharedPreferences;
        this.mImageView = imageView;

    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected byte[] doInBackground(String... strings) {

        if (strings[0] != "get_img") {

            switch (strings[0]) {
                case ("new_user"):

                    Log.i(LOG_TAG, "sending new user...");
                    //mByteContent = mInfoToSend.new_user().getBytes("UTF-8");
                    break;

                case ("new_img"):
                    Log.i(LOG_TAG, "sending new image");
                    try {
                        mInfoToSend.new_img();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;

                case("get_result"):
                    Log.i(LOG_TAG, "sending get result");
                    /*try {
                        //mByteContent = mInfoToSend.get_result().getBytes();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }*/
                    break;
            }

            return mByteContent;
        } else{
            Log.i(LOG_TAG, "sending get img");

            //mByteImage = mInfoToSend.get_img(mImageView);
            return mByteImage;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    protected void onPostExecute(byte[] content) {
        super.onPostExecute(content);

        SharedPreferences.Editor mEditor = mSharedPreferences.edit();
        if (mInfoToSend.byteImage != null){
            Log.i(LOG_TAG, "Пока что ничего не произойдет, но в скором времени тут будет вывод картинки");
            //Bitmap mBitmap = BitmapFactory.decodeByteArray(content, 0, content.length);
            //mImageView.setImageBitmap(mBitmap);
        }
        else {
            Log.i(LOG_TAG, content.toString());

            try {
                String someString = new String(content);
                mServerData = new JSONObject(new String(content));
                Log.i(LOG_TAG, "User's key: " + mServerData.getString("key"));
                mInfoToSend.user_key = mServerData.getString("key");
                mEditor.putString("user_key", mServerData.getString("key"));
                if(mServerData.has("img_key")){
                    mEditor.putString("img_key",mServerData.getString("img_key"));
                }
                mEditor.commit();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }
}