package com.e.avision;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;

import static com.e.avision.Camera_Activity.LOG_TAG;


public class Server_Activity extends AppCompatActivity {

    private File mFile;

    private static String defaultKey = "G!g9gCe&@g@#w5l";
    private String cur_img_name;
    private int j;

    public InfoToSend mInfoToSend;
    public SharedPreferences mSharedPreferences;
    private long StartTime;
    private long CurTime;


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(LOG_TAG, "TIME onCreate Server Activity");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server);
        Log.i(LOG_TAG, "Server_Activity: onCreate");

        mSharedPreferences = getSharedPreferences("aVisionPreferences", MODE_PRIVATE);

        if(!mSharedPreferences.contains("user_name")){
            String userID = UUID.randomUUID().toString();
            SharedPreferences.Editor mEditor = mSharedPreferences.edit();
            mEditor.putString("user_name", userID);
            mEditor.commit();
        }
        if(!mSharedPreferences.contains("user_key")){
            SharedPreferences.Editor mEditor = mSharedPreferences.edit();
            mEditor.putString("user_key", defaultKey);
            mEditor.commit();
        }

        cur_img_name = mSharedPreferences.getString("cur_img_name", "");
        j = mSharedPreferences.getInt("j", 0);
        mFile = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), cur_img_name + j + ".jpg");

        MyNewAsync myNewAsync = new MyNewAsync(Util.mByteJPEG, mFile, this);
        myNewAsync.execute("something");

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onResume(){
        super.onResume();
        Log.i(LOG_TAG, "TIME Server_Activity: onResume");
        StartTime = System.currentTimeMillis();
        CurTime = System.currentTimeMillis();


        mSharedPreferences = getSharedPreferences("aVisionPreferences", MODE_PRIVATE);


        Log.i(LOG_TAG, "TIME Server_Activity: onResume after while's");
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onPause() {
        super.onPause();
        Log.i(LOG_TAG, "Server_Activity: onPause");
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(LOG_TAG, "Server_Activity: onDestroy");
    }

    public static class MyNewAsync extends AsyncTask<String, Integer, JSONObject> {

        private byte[] mBytes = null;
        private File mFile = null;
        private JSONObject mContentFromServer;
        private Long mStartTime;
        private Long mCurrentTime;
        private AppCompatActivity mActivity;
        private String user_key;
        private String user_name;

        protected MyNewAsync(byte[] bytes, File file, AppCompatActivity appCompatActivity) {

            this.mBytes = bytes;
            this.mFile = file;
            this.mActivity = appCompatActivity;
        }

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        protected JSONObject doInBackground(String... strings) {


            FileOutputStream outputStream = null;
            SharedPreferences sharedPreferences = Util.getSharedPreferences(mActivity);
            SharedPreferences.Editor mEditor = sharedPreferences.edit();

            user_key = sharedPreferences.getString("user_key","");

            user_name = sharedPreferences.getString("user_name",null);

            InfoToSend infoToSend = new InfoToSend(user_name, user_key, "no", null, null);

            if(user_key.equals(defaultKey)) {

                try {
                    mContentFromServer = infoToSend.new_user();
                    if(mContentFromServer != null){
                    Log.i(LOG_TAG, "User's key: " + mContentFromServer.getString("key"));
                    infoToSend.setUser_key(mContentFromServer.getString("key"));
                    mEditor.putString("user_key", mContentFromServer.getString("key"));
                    mEditor.commit();}
                } catch (JSONException e) {
                    e.printStackTrace();
                    mContentFromServer = null;
                }
            }
            if(!(sharedPreferences.getString("usser_key","").equals(defaultKey))){
                String user_name = sharedPreferences.getString("user_name", "");
                String user_key = sharedPreferences.getString("user_key", "");
                String cur_img_name = sharedPreferences.getString("cur_img_name", "");
                String img_key = sharedPreferences.getString("cur_img_key", "");
                int j = sharedPreferences.getInt("j", 0);

                infoToSend.setUser_name(user_name);
                infoToSend.setUser_key(user_key);
                infoToSend.setImg_name(cur_img_name + j + ".jpg");
                infoToSend.setImg_key(img_key);
                infoToSend.setByteImage(mBytes);

                try {
                    infoToSend.new_img();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                mEditor.putString("new_img_status", "ok");
                mEditor.putString("img_text", "");
                mEditor.commit();


                try {
                    outputStream = new FileOutputStream(mFile);
                    outputStream.write(mBytes);
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (outputStream != null) {
                        try {
                            outputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

                try {
                    mContentFromServer = infoToSend.get_result();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (!(mContentFromServer == null)) {
                    mStartTime = System.currentTimeMillis();
                    try {
                        mEditor.putString("cur_img_status", mContentFromServer.getString("img_status"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    mEditor.commit();

                    while (sharedPreferences.getString("cur_img_status", "work").equals("work")) {
                        mCurrentTime = System.currentTimeMillis();
                        if ((mCurrentTime - mStartTime) >= 10) {
                            try {
                                mStartTime = System.currentTimeMillis();
                                mContentFromServer = infoToSend.get_result();
                                mEditor.putString("cur_img_status", mContentFromServer.getString("img_status"));
                                mEditor.commit();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    Log.i(LOG_TAG, "Img was successfully processed");
                    try {
                        mEditor.putString("cur_img_key", mContentFromServer.getString("img_key"));
                        mEditor.commit();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
            return mContentFromServer;
        }

        @Override
        protected void onPostExecute(JSONObject s) {
            super.onPostExecute(s);
            Intent intent = new Intent(mActivity, PictureFromServerActivity.class);
            if(s == null){
                intent.putExtra("JSON", "null");
            }else{
                intent.putExtra("JSON", s.toString());
            }
            mActivity.startActivity(intent);
            mActivity.finish();
        }
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();

    }

}
