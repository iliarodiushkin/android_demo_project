package com.e.avision;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import static com.e.avision.Camera_Activity.LOG_TAG;

public class PictureFromServerActivity extends AppCompatActivity {

    public SharedPreferences  mSharedPreferences;
    public InfoToSend mInfoToSend;
    private GetBitmapAsync mGetBitmapAsync;

    Intent intent;
    JSONObject jsonObject;

    public ImageView mImageView;
    public TextView mTextView;

    public Button mButton;
    public Button mButton2;

    @Override
    public void onBackPressed() {
        //super.onBackPressed();

    }

    @SuppressLint("WrongViewCast")
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.picture_from_server_activity);


        mImageView = findViewById(R.id.imageView3);
        mTextView = findViewById(R.id.textView2);
        mButton = findViewById(R.id.button6);
        mButton2 = findViewById(R.id.button5);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PictureFromServerActivity.this, Camera_Activity.class);
                startActivity(intent);
                PictureFromServerActivity.this.finish();

            }

        });

        mButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PictureFromServerActivity.this, StartMenu_Activity.class);
                startActivity(intent);
                PictureFromServerActivity.this.finish();
            }

        });

        mSharedPreferences = getSharedPreferences("aVisionPreferences", MODE_PRIVATE);

        intent = getIntent();
        if(!(intent.getStringExtra("JSON").equals("null"))) {

            try {
                jsonObject = new JSONObject(intent.getStringExtra("JSON"));
            } catch (JSONException e) {
                e.printStackTrace();
            }

            mInfoToSend = new InfoToSend(mSharedPreferences.getString("user_name", ""), mSharedPreferences.getString("user_key", ""),
                    mSharedPreferences.getString("cur_img_name", "") + mSharedPreferences.getInt("j", 0) + ".jpg", mSharedPreferences.getString("cur_img_key", ""), null);


            mGetBitmapAsync = new GetBitmapAsync(mInfoToSend, mImageView);

            mGetBitmapAsync.execute("get_img");
        }

        Bitmap bitmap = Bitmap.createBitmap(460, 230, Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(Color.WHITE);

    }

    @Override
    protected void onResume() {
        super.onResume();
        if(intent.getStringExtra("JSON").equals("null")){
            mTextView.setText("Возникли некоторые проблемы, связь прервалась");
        }else {
            try {
                mTextView.setText(jsonObject.getString("text"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
